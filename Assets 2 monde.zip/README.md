# Assets Cursed Land + Undead Land : version prête pour le web

Tout est en pixel art, sur une grille de **16×16 px**. Rien n'a été redimensionné ni retouché : les images sont seulement découpées et rangées.

## Où mettre quoi dans ton projet

```
public/assets/
  atlases/       cursed-objects.png/.json, undead-objects.png/.json
  animations/    undead-anim{1..6}-shadow{1..3}.png + animations.json
  tilesets/      cursed-land/*.png + .tsx, undead-land/*.png + .tsx, tilesets.json
src/assets/      loader.ts, draw.ts, types.ts, assetNames.ts, index.ts
licenses/        licences des deux packs
```

Le chemin `/assets` est défini dans `src/assets/loader.ts` (`ASSET_ROOT`). Avec Vite, tout ce qui est dans `public/` est servi à la racine, donc `public/assets/` donne bien `/assets/...`.

## Ce qui a été fait

- **Objets** : les 127 sprites Cursed et les 240 sprites Undead (arbres, tombes, rochers, plantes, os...) sont regroupés en 2 atlas, avec un JSON au format « hash » (lisible par Phaser, PixiJS ou du canvas pur). Les noms sont en minuscules, sans espace. J'ai corrigé trois fautes du pack d'origine : `palnt` → `plant`, `scull` → `skull`, `sculls` → `skulls`.
- **Animations** : les 6 feuilles `Animation1..6` contiennent chacune 6 images × 3 variantes d'ombre. Elles sont découpées en 18 bandes horizontales, une par variante. Durée par image : 150 ms, la même que dans les cartes Tiled d'origine.
- **Tilesets** : les images utilisées par les cartes `.tmx` du pack (dossier `Tiled_files`) sont copiées, avec un `.tsx` par image. Les animations d'eau et d'objets animés sont recopiées dans les `.tsx` : tu peux donc construire tes cartes dans Tiled et exporter en JSON.
- **Non repris** : les `.psd` (trop lourds, inutiles en jeu), les `COUPON.*`, et les dossiers `PNG/` qui contiennent des morceaux d'autotiles en vrac (pas une grille régulière).

## Conventions à respecter

1. **Origine des objets : bas, centre.** Quand tu poses un arbre en `(x, y)`, `y` correspond à ses pieds. `drawSprite` et `StripAnimation.draw` suivent cette règle.
2. **Ordre d'affichage : trie les objets par `y`** avant de les dessiner, sinon un joueur passera devant un arbre alors qu'il est derrière.
3. **Désactive le lissage** (`ctx.imageSmoothingEnabled = false`, ou `pixelArt: true` dans Phaser), sinon tout devient flou.
4. **Variantes `shadow1/2/3`** : même objet avec un style d'ombre différent. Choisis-en une et garde-la pour tout le jeu, sinon les ombres ne seront pas cohérentes.
5. **Indices de tuiles** : `drawTile` prend un index local (0 = première tuile de l'image). Dans une carte Tiled, `gid - firstgid` donne cet index, et `gid = 0` signifie « vide ».
6. **Eau** : les images `water*.png` contiennent 6 images d'animation empilées. Les liens entre tuiles sont dans le `.tsx` (attribut `<animation>`), pas calculables par un simple décalage fixe.

## Exemple minimal (canvas)

```ts
import { loadAtlas, loadAnimationDefs, loadAnimationImage, StripAnimation, drawSprite, setupPixelArt } from "./assets";

const ctx = canvas.getContext("2d")!;
setupPixelArt(ctx);

const objects = await loadAtlas("undead-objects");
const defs = await loadAnimationDefs();
const def = defs["undead-anim1-shadow1"];
const tree = new StripAnimation(await loadAnimationImage(def), def);

function frame(dt: number) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawSprite(ctx, objects, "grave_shadow1_1", 120, 200);
  tree.update(dt);
  tree.draw(ctx, 220, 200);
}
```

## Prompt à coller dans ton assistant de code

> Mon jeu 2D web est en TypeScript. J'ajoute les dossiers `public/assets/` et `src/assets/` fournis (atlas d'objets, bandes d'animation, tilesets 16×16 avec .tsx).
>
> Conventions : grille de 16 px, origine des sprites en bas au centre, tri des objets par `y`, lissage désactivé, animations à 150 ms par image.
>
> À faire :
> 1. Dire quel moteur ou quelle approche convient à mon projet (canvas pur, Phaser 3, PixiJS), à partir de mon code actuel, et adapter `loader.ts` / `draw.ts` en conséquence. Ne pas réécrire ce qui fonctionne déjà.
> 2. Charger les assets une seule fois au démarrage, avec un écran de chargement simple.
> 3. Afficher un terrain de test avec les tuiles de `cursed_ground` et `undead_ground_rocks`, quelques objets posés depuis les atlas, et une animation `undead-anim1-shadow1`.
> 4. Ajouter une couche de collision basée sur la taille de chaque objet (par exemple un rectangle sur le bas du sprite), à renseigner dans un fichier de données à part et non dans le code.
> 5. Me dire ce qui reste à décider de mon côté (choix de la variante d'ombre, taille de la caméra, échelle d'affichage) au lieu de le fixer arbitrairement.

## Points à vérifier de ton côté

- **Licence** : chaque pack contient un `License.txt` qui renvoie vers la page de licences de Craftpix. Lis-la avant de publier le jeu, surtout si tu comptes le diffuser ou le vendre.
- **Échelle** : en 16 px, un personnage et un arbre n'ont pas la même échelle visuelle. Teste avec ton sprite de joueur avant de fixer le zoom.
- **Moteur** : j'ai écrit le chargeur pour du canvas 2D, sans dépendance. Si tu utilises Phaser ou PixiJS, les JSON d'atlas se chargent directement (`this.load.atlas(...)` dans Phaser), le chargeur devient inutile.
