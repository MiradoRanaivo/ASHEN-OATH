DEMON OVERLORD - 2D PIXEL ART SPRITE PACK
Version 1.0.0

A horned demon overlord boss: idle, walk, attack, special, hurt and death.
8 frames each, 320 x 320 cells, transparent background, facing right.


--------------------------------------------------------------------------
CONTENTS
--------------------------------------------------------------------------

License.txt ......... terms of use - read this first
Preview.gif ......... all six animations, looping
Cover.png ........... 630 x 500 promo image

Sprites/
  Idle/      DemonOverlord-Idle.png      Preview.gif
  Walk/      DemonOverlord-Walk.png      Preview.gif
  Attack/    DemonOverlord-Attack.png    Preview.gif
  Special/   DemonOverlord-Special.png   Preview.gif
  Hurt/      DemonOverlord-Hurt.png      Preview.gif
  Death/     DemonOverlord-Death.png     Preview.gif

  Each PNG is a 2560 x 320 strip of 8 frames. Each Preview.gif loops that
  one animation.

Godot/
  demon_overlord_idle.png ... demon_overlord_death.png    160 x 160 cells
  demon_overlord_frames.tres                              SpriteFrames resource


--------------------------------------------------------------------------
SHEET FORMAT
--------------------------------------------------------------------------

Cell ............ 320 x 320 px
Layout .......... 8 frames, one horizontal strip (2560 x 320 px)
Background ...... transparent
Facing .......... right
Ground row ...... y = 300 - the feet line every animation is aligned to

Sheets are full resolution: no downscaling, no palette reduction.

Frame rates (suggested):

  Idle      7 fps   loop
  Walk     10 fps   loop
  Attack   14 fps   once
  Special  14 fps   once    (magic / skill)
  Hurt     12 fps   once
  Death     8 fps   once, hold the last frame

Any engine: slice a strip into 8 cells of 320 x 320.


--------------------------------------------------------------------------
GODOT 4
--------------------------------------------------------------------------

1. Copy Godot/ into your project as  res://demon_overlord/
   (the .tres expects that path).
2. Add an AnimatedSprite2D and set Sprite Frames to
   res://demon_overlord/demon_overlord_frames.tres
3. Six animations are defined: idle, walk, attack, cast, hurt, death.
   "cast" is the Special sheet. Feet are on y = 150 of the 160 px cells.


--------------------------------------------------------------------------
LICENCE
--------------------------------------------------------------------------

Free for personal and commercial use - see License.txt.
Credit appreciated, not required.
