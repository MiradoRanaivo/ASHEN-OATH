# Boss — Roi Squelette Déchu (Web 2D / Phaser 3)

## Fichier
- `assets/boss_skeleton_sprite_sheet.png` — PNG RGBA 1536 × 1024, fond transparent.

## Important
- Les effets magiques et les arcs d'épée n'ont pas de cadres rectangulaires dessinés autour d'eux. Les halos et traînées sont des formes libres avec transparence.
- La planche est une composition d'animations en rangées, mais les cellules n'ont pas toutes la même largeur ni la même hauteur. Ce n'est donc pas une spritesheet Phaser à grille régulière (`frameWidth` / `frameHeight`) prête à charger telle quelle.
- Pour une intégration fiable, il faut découper chaque pose/effet en PNG indépendant ou définir des rectangles de frames personnalisés, puis créer les animations Phaser.

## Chargement Phaser 3
```js
this.load.image('boss-skeleton-sheet', 'assets/boss_skeleton_sprite_sheet.png');
```

Ce chargement affiche la planche entière. Pour jouer les animations, utilisez des images découpées ou un atlas JSON avec des coordonnées vérifiées.
